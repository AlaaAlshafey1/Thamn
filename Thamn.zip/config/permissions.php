<?php

return [
    'users' => [
        'users_view',
        'users_create',
        'users_edit',
        'users_delete',
    ],

    'roles' => [
        'roles_view',
        'roles_create',
        'roles_edit',
        'roles_delete',
    ],
       'categories' => [
        'categories_view',
        'categories_create',
        'categories_edit',
        'categories_delete',
    ],
       'questions' => [
        'questions_view',
        'questions_create',
        'questions_edit',
        'questions_delete',
    ],
       'app_pages' => [
        'app_pages_view',
        'app_pages_create',
        'app_pages_edit',
        'app_pages_delete',
    ],






];
